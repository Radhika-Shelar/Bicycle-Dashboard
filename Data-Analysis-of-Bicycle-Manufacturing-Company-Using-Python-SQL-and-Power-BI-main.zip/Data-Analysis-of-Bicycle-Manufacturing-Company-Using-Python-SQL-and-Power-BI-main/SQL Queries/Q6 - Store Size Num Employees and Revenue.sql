SELECT SquareFeet, NumberEmployees, AnnualRevenue
FROM Sales.vStoreWithDemographics
ORDER BY squarefeet DESC
